# Ember & Ash — Landing Page

A static landing page for **Ember & Ash**, a fictional small-batch, fire-fermented hot sauce brand. Built for Ask 1 (Landing Page) — pure HTML5 + CSS3, no JavaScript, no build step.

## Preview
Open `index.html` directly in a browser, or serve the folder locally:

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .
```

Then visit `http://localhost:8000`.

## Structure
```
ember-ash/
├── index.html     # markup + content
├── styles.css     # all styling (tokens, layout, responsive rules)
└── README.md
```

## What's included
- Sticky nav bar with logo, 3 links (Sauces / Our Process / Reviews), and a CTA button
- Hero section with eyebrow, headline, subheadline, and two CTA buttons
- "Our Process" section — 4-step numbered sequence (real fermentation steps)
- "The Lineup" section — 3 product cards, each with a heat-level meter (signature visual motif)
- "Reviews" section — 3 testimonials
- CTA strip + footer with contact and social placeholder links
- Fully responsive via CSS Grid/Flexbox, with breakpoints at 900px, 720px, and 420px
- Consistent design tokens (colour, type, spacing) defined as CSS custom properties in `:root`
- Visible keyboard focus states and `prefers-reduced-motion` support

## Fonts
Loaded from Google Fonts via CDN (no local files needed):
- **Fraunces** — display/heading typeface
- **Work Sans** — body/utility typeface

## Deploying on GitHub Pages
1. Push this folder to a new GitHub repo.
2. In the repo, go to **Settings → Pages**.
3. Under "Build and deployment," set source to the `main` branch, root folder.
4. Your site will be live at `https://<username>.github.io/<repo-name>/`.
