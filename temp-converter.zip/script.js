// ============ Elements ============
const form = document.getElementById('converterForm');
const input = document.getElementById('tempInput');
const errorMsg = document.getElementById('errorMsg');
const results = document.getElementById('results');

const valueC = document.getElementById('valueC');
const valueF = document.getElementById('valueF');
const valueK = document.getElementById('valueK');

const gaugeC = document.getElementById('gaugeC');
const gaugeF = document.getElementById('gaugeF');
const gaugeK = document.getElementById('gaugeK');

// Absolute zero, in each unit
const ABSOLUTE_ZERO_C = -273.15;
const ABSOLUTE_ZERO_F = -459.67;
const ABSOLUTE_ZERO_K = 0;

// ============ Helpers ============
function getSelectedUnit() {
  const checked = form.querySelector('input[name="unit"]:checked');
  return checked ? checked.value : 'C';
}

function showError(message) {
  errorMsg.textContent = message;
  errorMsg.hidden = false;
  input.classList.add('invalid');
  results.hidden = true;
}

function clearError() {
  errorMsg.textContent = '';
  errorMsg.hidden = true;
  input.classList.remove('invalid');
}

function toCelsius(value, unit) {
  if (unit === 'C') return value;
  if (unit === 'F') return (value - 32) * (5 / 9);
  if (unit === 'K') return value - 273.15;
  return value;
}

function formatNumber(n) {
  // round to 2 decimal places, trim trailing zeros
  return (Math.round(n * 100) / 100).toString();
}

// Maps a Celsius value to a 0–100% gauge position across a fixed
// display range, purely for the visual fill — clamped at both ends.
function gaugePercent(celsius) {
  const MIN = -50;   // display floor
  const MAX = 150;   // display ceiling
  const pct = ((celsius - MIN) / (MAX - MIN)) * 100;
  return Math.max(0, Math.min(100, pct));
}

// ============ Core convert flow ============
function handleConvert(event) {
  event.preventDefault();
  clearError();

  const raw = input.value.trim();

  // 1. Reject empty input
  if (raw === '') {
    showError('Enter a temperature value to convert.');
    return;
  }

  // 2. Reject non-numeric input
  const value = Number(raw);
  if (Number.isNaN(value) || !/^-?\d*\.?\d+$/.test(raw)) {
    showError(`"${raw}" isn't a valid number. Use digits only, e.g. -40 or 98.6.`);
    return;
  }

  const unit = getSelectedUnit();

  // 3. Reject values below absolute zero, in the selected unit's own terms
  const belowZero =
    (unit === 'C' && value < ABSOLUTE_ZERO_C) ||
    (unit === 'F' && value < ABSOLUTE_ZERO_F) ||
    (unit === 'K' && value < ABSOLUTE_ZERO_K);

  if (belowZero) {
    showError(
      `That's below absolute zero. The lowest possible temperature is ` +
      `${ABSOLUTE_ZERO_C}\u00B0C (${ABSOLUTE_ZERO_F}\u00B0F / ${ABSOLUTE_ZERO_K} K).`
    );
    return;
  }

  // 4. Convert via Celsius as the common base
  const c = toCelsius(value, unit);
  const f = c * (9 / 5) + 32;
  const k = c + 273.15;

  valueC.textContent = `${formatNumber(c)}\u00B0`;
  valueF.textContent = `${formatNumber(f)}\u00B0`;
  valueK.textContent = `${formatNumber(k)} K`;

  const pct = gaugePercent(c);
  gaugeC.style.width = `${pct}%`;
  gaugeF.style.width = `${pct}%`;
  gaugeK.style.width = `${pct}%`;

  results.hidden = false;
}

// ============ Wire up events ============
form.addEventListener('submit', handleConvert);

// Clear stale error state as soon as the user edits the input again
input.addEventListener('input', () => {
  if (!errorMsg.hidden) clearError();
});

form.querySelectorAll('input[name="unit"]').forEach((radio) => {
  radio.addEventListener('change', () => {
    if (!errorMsg.hidden) clearError();
  });
});
