# Temperature Converter — °C / °F / K

A static, vanilla-JS temperature converter built for Ask 3 (Temperature Converter Website). Converts between Celsius, Fahrenheit, and Kelvin with real-time validation, non-numeric input rejection, and absolute-zero checking. No frameworks, no build step, no dependencies.

## Preview
Open `index.html` directly in a browser, or serve the folder locally:

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .
```

Then visit `http://localhost:8000`.

## Structure
```
temp-converter/
├── index.html                # markup + content
├── styles.css                 # all styling (tokens, layout, responsive rules)
├── script.js                  # conversion logic + validation
├── README.md
├── LICENSE                    # MIT
├── .gitignore
└── .github/
    └── workflows/
        └── deploy.yml          # auto-deploys to GitHub Pages on push to main
```

## What's included
- Centered instrument-panel layout with a numeric input and a three-way °C/°F/K unit toggle
- **Convert** button (also works via Enter, since it's a real form submit)
- Real-time input validation:
  - Empty input → friendly error, no crash
  - Non-numeric input (letters, symbols) → rejected with an error message, results hidden
  - Value below absolute zero for the selected unit → rejected with a message stating the actual floor in all three units
- Once a valid value is submitted, all three units display simultaneously — Celsius, Fahrenheit, and Kelvin — each with its own small gauge bar showing where that temperature sits on a fixed −50°C to 150°C scale
- Errors clear automatically as soon as the user edits the input or switches units
- Fully responsive, accessible markup: proper `<label>`s, `role="radiogroup"`, `aria-live` regions for both the error message and results, and visible keyboard focus states

## Conversion formulas used
- °F → °C: `(F − 32) × 5/9`
- K → °C: `K − 273.15`
- °C → °F: `C × 9/5 + 32`
- °C → K: `C + 273.15`
- Absolute zero: −273.15°C / −459.67°F / 0 K

## Fonts
Loaded from Google Fonts via CDN (no local files needed):
- **IBM Plex Mono** — numeric readouts and unit toggle
- **Inter** — labels and UI text

## Deploying on GitHub Pages

**Option A — automatic (recommended, already set up):**
1. Push this repo to GitHub (see below).
2. Go to **Settings → Pages**, and under "Build and deployment" set **Source** to **GitHub Actions**.
3. The included `.github/workflows/deploy.yml` builds and deploys automatically on every push to `main`.
4. Your site will be live at `https://<username>.github.io/<repo-name>/`.

**Option B — manual, no Actions:**
1. Push this repo to GitHub.
2. Go to **Settings → Pages**, set **Source** to the `main` branch, root folder.
3. Save — the site deploys within a minute or two.

## Pushing to a new GitHub repo
From inside this folder:
```bash
git init
git add .
git commit -m "Initial commit: temperature converter"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```
