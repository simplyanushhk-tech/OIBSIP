# Alex Rivera — Personal Portfolio

A static personal portfolio / digital résumé built for Ask 2 (Personal Portfolio). Pure HTML5 + CSS3, with a small amount of vanilla JavaScript for the mobile nav toggle and active-section highlighting. No build step, no frameworks.

**All content (name, role, bio, projects, links) is placeholder text for "Alex Rivera," a fictional frontend engineer — swap it for your own details before publishing.** Search for every instance of `Alex Rivera`, `alexrivera.example`, and the placeholder project names to find what to edit.

## Preview
Open `index.html` directly in a browser, or serve the folder locally:

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .
```

Then visit `http://localhost:8000`.

## Structure
```
portfolio/
├── index.html                # markup + content
├── styles.css                 # all styling (tokens, layout, responsive rules)
├── script.js                  # mobile nav toggle + active-link scroll highlighting
├── README.md
├── LICENSE                    # MIT
├── .gitignore
└── .github/
    └── workflows/
        └── deploy.yml          # auto-deploys to GitHub Pages on push to main
```

## What's included
- Sticky nav with smooth-scroll links, a mobile hamburger toggle, and scroll-based active-link highlighting
- Hero section with name, role/tagline, an avatar placeholder (initials in a circle — swap for a real photo), and two CTAs
- About section with a short bio plus a "spec sheet" of quick facts (location, focus, currently learning)
- Skills section grouped into three categories (Frontend / Backend & Data / Tools & Practice) as tag chips
- Projects section with 3 placeholder project cards, each with a description, tech-stack tags, and GitHub/Live link placeholders
- Contact section with an email link and GitHub / LinkedIn / X icon links (inline SVG, no icon library needed)
- Consistent blueprint-navy / paper / amber colour system and Space Grotesk + Inter + JetBrains Mono type pairing throughout
- Fully responsive via CSS Grid/Flexbox, with breakpoints at 900px, 720px, and 420px
- Visible keyboard focus states and `prefers-reduced-motion` support

## Before you publish — swap in your own details
1. **Hero**: name, tagline, avatar initials (`index.html`, `.avatar-placeholder`)
2. **About**: bio paragraphs and the four spec-sheet rows
3. **Skills**: edit the three `<ul class="skill-tags">` lists to match your stack
4. **Projects**: replace the 3 project cards with your own (title, description, tech tags, and real GitHub/live links — swap the `href="#"` placeholders)
5. **Contact**: email address and the 3 social link `href="#"` placeholders
6. **Title/meta tags**: update `<title>` and the meta description at the top of `index.html`

## Fonts
Loaded from Google Fonts via CDN (no local files needed):
- **Space Grotesk** — display/heading typeface
- **Inter** — body typeface
- **JetBrains Mono** — labels, tags, and code-style accents

## Deploying on GitHub Pages

**Option A — automatic (recommended, already set up):**
1. Push this repo to GitHub (see below).
2. Go to **Settings → Pages**, and under "Build and deployment" set **Source** to **GitHub Actions**.
3. The included `.github/workflows/deploy.yml` builds and deploys automatically on every push to `main`.
4. Your site will be live at `https://<username>.github.io/<repo-name>/`.

**Option B — manual, no Actions:**
1. Push this repo to GitHub.
2. Go to **Settings → Pages**, set **Source** to the `main` branch, root folder.
3. Save — the site deploys within a minute or two.

## Pushing to a new GitHub repo
From inside this folder:
```bash
git init
git add .
git commit -m "Initial commit: personal portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```
