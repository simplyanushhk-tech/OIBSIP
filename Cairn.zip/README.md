# Cairn — Task Manager (Android)

A native Android to-do app built for this task: users register and log in
before they can see or touch their tasks, and everything persists locally
in a SQLite database. Java + XML, no third-party backend, no network
permission at all — it's fully offline by design.

The name/branding is "Cairn" (a stack of stones used as a trail marker) —
feel free to rename it before you publish.

## Feature checklist coverage

- [x] **Login screen** — email + password fields, Login button (`LoginActivity`)
- [x] **Sign-up screen** — name, email, password fields, Register button (`RegisterActivity`)
- [x] **Passwords hashed, never stored in plain text** — SHA-256 with a random
      per-user salt (`PasswordUtils`); only the hash + salt are written to SQLite
- [x] **Logout** — toolbar menu action in the task list, clears the session
      (`SessionManager#logout`) and returns to the login screen
- [x] **Task list screen** — shows every task belonging to the logged-in user only
- [x] **Add Task** — floating action button opens a dialog (name + optional notes)
- [x] **Mark complete** — checkbox per task; completed tasks get a strikethrough,
      dim slightly, and sort to the bottom of the list
- [x] **Delete task** — trash icon per row, with a confirmation dialog first
- [x] **Tasks are user-specific** — `tasks.user_id` foreign-keys to `users._id`;
      every query filters by the current session's user id
- [x] **Empty state** — friendly message + prompt shown when a user has no tasks

## Security notes (read this before shipping anywhere real)

- Passwords are hashed with **SHA-256 + a random 16-byte salt per user**
  (see `PasswordUtils.java`). This satisfies "don't store plain text" for a
  learning project, but SHA-256 is a *fast* general-purpose hash — it's not
  designed to resist brute-force/GPU cracking the way a dedicated password
  hash is. For anything beyond a demo, swap in **bcrypt, scrypt, or Argon2**
  (there are small Java/Android libraries for all three).
- The app requests **no permissions at all** — no internet access, since
  everything is local. `android:allowBackup="false"` is set deliberately so
  Android doesn't auto-backup the database (with its password hashes) to
  the cloud.
- Session state (`SessionManager`) only ever stores the user's id, name,
  and email in `SharedPreferences` — never the password or its hash.

## Project structure

```
Cairn/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/cairn/tasks/
│       │   ├── data/TaskDbHelper.java      # SQLiteOpenHelper: users + tasks tables, all CRUD
│       │   ├── model/Task.java             # plain data holder
│       │   ├── ui/LoginActivity.java
│       │   ├── ui/RegisterActivity.java
│       │   ├── ui/TaskListActivity.java
│       │   ├── ui/TaskAdapter.java         # RecyclerView adapter
│       │   ├── ui/AddTaskDialogFragment.java
│       │   └── util/PasswordUtils.java     # salted SHA-256 hashing
│       │   └── util/SessionManager.java    # SharedPreferences-backed session
│       └── res/
│           ├── layout/                     # activity_login, activity_register,
│           │                               # activity_task_list, item_task, dialog_add_task
│           ├── values/                     # strings.xml, colors.xml, themes.xml
│           ├── drawable/                   # ic_add, ic_delete, launcher icon vectors
│           ├── mipmap-anydpi-v26/          # adaptive launcher icon
│           └── menu/                       # toolbar logout menu
├── build.gradle                # project-level
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── LICENSE
└── .gitignore
```

## Database schema

```sql
CREATE TABLE users (
    _id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    salt            TEXT NOT NULL
);

CREATE TABLE tasks (
    _id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL,
    title           TEXT NOT NULL,
    notes           TEXT,
    is_complete     INTEGER NOT NULL DEFAULT 0,
    created_at      INTEGER NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(_id) ON DELETE CASCADE
);
```

## Opening the project

1. Open **Android Studio** → **Open** → select the `Cairn/` folder.
2. Let Gradle sync. This repo does **not** include the Gradle wrapper
   scripts (`gradlew` / `gradlew.bat`) or the wrapper jar, since the jar is
   a binary file. Android Studio will either:
   - offer to regenerate the wrapper automatically, or
   - just use the Gradle version bundled with your Android Studio install.
   Either is fine — accept the prompt if you see one.
3. Once synced, run the `app` configuration on an emulator or device
   (**minSdk 26 / Android 8.0** or newer).
4. Register a new account, then log in — that's the whole flow.

If you'd rather generate the wrapper yourself from the command line once
you have Gradle installed locally:
```bash
gradle wrapper --gradle-version 8.4
```

## Pushing to a new GitHub repo
From inside this folder:
```bash
git init
git add .
git commit -m "Initial commit: Cairn task manager"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

## Things you might reasonably extend next
- Swap SHA-256 for bcrypt/Argon2 (see security notes above)
- Add "remember me" vs. session-only login
- Add due dates / priority / sorting options
- Add a settings screen for editing the account name or changing password
