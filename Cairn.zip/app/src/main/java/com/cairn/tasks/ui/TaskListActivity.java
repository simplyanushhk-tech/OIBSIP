package com.cairn.tasks.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.cairn.tasks.R;
import com.cairn.tasks.data.TaskDbHelper;
import com.cairn.tasks.model.Task;
import com.cairn.tasks.util.SessionManager;

import java.util.List;

/**
 * Main screen after login: shows every task belonging to the current user,
 * lets them add, complete, and delete tasks, and log out.
 */
public class TaskListActivity extends AppCompatActivity implements TaskAdapter.Listener {

    private TaskDbHelper dbHelper;
    private SessionManager sessionManager;
    private TaskAdapter adapter;
    private View emptyStateView;
    private TextView greetingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHelper = TaskDbHelper.getInstance(this);
        sessionManager = new SessionManager(this);

        if (!sessionManager.isLoggedIn()) {
            goToLogin();
            return;
        }

        setContentView(R.layout.activity_task_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        greetingView = findViewById(R.id.text_greeting);
        emptyStateView = findViewById(R.id.layout_empty_state);
        RecyclerView recyclerView = findViewById(R.id.recycler_tasks);
        FloatingActionButton addButton = findViewById(R.id.fab_add_task);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(this);
        recyclerView.setAdapter(adapter);

        addButton.setOnClickListener(v -> showAddTaskDialog());

        String name = sessionManager.getUserName();
        String displayName = (name != null && !name.isEmpty()) ? name : sessionManager.getUserEmail();
        greetingView.setText(getString(R.string.greeting_format, displayName));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sessionManager.isLoggedIn()) {
            refreshTasks();
        }
    }

    private void refreshTasks() {
        List<Task> tasks = dbHelper.getTasksForUser(sessionManager.getUserId());
        adapter.submitList(tasks);
        emptyStateView.setVisibility(tasks.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showAddTaskDialog() {
        AddTaskDialogFragment dialog = new AddTaskDialogFragment();
        dialog.setListener((title, notes) -> {
            dbHelper.addTask(sessionManager.getUserId(), title, notes);
            refreshTasks();
        });
        dialog.show(getSupportFragmentManager(), "add_task");
    }

    @Override
    public void onToggleComplete(Task task, boolean complete) {
        dbHelper.setTaskComplete(task.getId(), complete);
        refreshTasks();
    }

    @Override
    public void onDelete(Task task) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_task_title)
                .setMessage(R.string.delete_task_message)
                .setPositiveButton(R.string.action_delete, (dialog, which) -> {
                    dbHelper.deleteTask(task.getId());
                    refreshTasks();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_task_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            sessionManager.logout();
            goToLogin();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
