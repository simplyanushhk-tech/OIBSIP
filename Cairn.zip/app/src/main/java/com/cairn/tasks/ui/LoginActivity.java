package com.cairn.tasks.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cairn.tasks.R;
import com.cairn.tasks.data.TaskDbHelper;
import com.cairn.tasks.util.SessionManager;

/**
 * App launcher screen. If a session is already active, skips straight to
 * {@link TaskListActivity} instead of showing the form again.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText emailInput;
    private EditText passwordInput;
    private TaskDbHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHelper = TaskDbHelper.getInstance(this);
        sessionManager = new SessionManager(this);

        if (sessionManager.isLoggedIn()) {
            goToTaskList();
            return;
        }

        setContentView(R.layout.activity_login);

        emailInput = findViewById(R.id.input_login_email);
        passwordInput = findViewById(R.id.input_login_password);
        Button loginButton = findViewById(R.id.button_login);
        TextView registerLink = findViewById(R.id.text_go_to_register);

        loginButton.setOnClickListener(v -> attemptLogin());
        registerLink.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void attemptLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError(getString(R.string.error_invalid_email));
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordInput.setError(getString(R.string.error_password_required));
            return;
        }

        TaskDbHelper.AuthResult result = dbHelper.authenticate(email, password);
        if (result == null) {
            Toast.makeText(this, R.string.error_invalid_credentials, Toast.LENGTH_SHORT).show();
            return;
        }

        sessionManager.createSession(result.userId, result.name, result.email);
        goToTaskList();
    }

    private void goToTaskList() {
        Intent intent = new Intent(this, TaskListActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
