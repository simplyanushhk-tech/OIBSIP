package com.cairn.tasks.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.cairn.tasks.model.Task;
import com.cairn.tasks.util.PasswordUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Single SQLite database for the app: one table of user accounts (with
 * salted+hashed passwords, never plain text) and one table of tasks, each
 * task linked to the user that owns it via a foreign key.
 */
public class TaskDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "cairn.db";
    private static final int DB_VERSION = 1;

    // ---- users table ----
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id";
    public static final String COL_USER_NAME = "name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD_HASH = "password_hash";
    public static final String COL_USER_SALT = "salt";

    // ---- tasks table ----
    public static final String TABLE_TASKS = "tasks";
    public static final String COL_TASK_ID = "_id";
    public static final String COL_TASK_USER_ID = "user_id";
    public static final String COL_TASK_TITLE = "title";
    public static final String COL_TASK_NOTES = "notes";
    public static final String COL_TASK_COMPLETE = "is_complete";
    public static final String COL_TASK_CREATED_AT = "created_at";

    private static TaskDbHelper instance;

    /** Shared instance so every screen talks to the same open database. */
    public static synchronized TaskDbHelper getInstance(Context context) {
        if (instance == null) {
            instance = new TaskDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    private TaskDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_NAME + " TEXT NOT NULL, " +
                COL_USER_EMAIL + " TEXT NOT NULL UNIQUE, " +
                COL_USER_PASSWORD_HASH + " TEXT NOT NULL, " +
                COL_USER_SALT + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_TASKS + " (" +
                COL_TASK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TASK_USER_ID + " INTEGER NOT NULL, " +
                COL_TASK_TITLE + " TEXT NOT NULL, " +
                COL_TASK_NOTES + " TEXT, " +
                COL_TASK_COMPLETE + " INTEGER NOT NULL DEFAULT 0, " +
                COL_TASK_CREATED_AT + " INTEGER NOT NULL, " +
                "FOREIGN KEY(" + COL_TASK_USER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ============ User operations ============

    /**
     * Registers a new user, hashing their password with a fresh random salt.
     *
     * @return the new user's row id, or -1 if the email is already registered.
     */
    public long registerUser(String name, String email, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String salt = PasswordUtils.generateSalt();
        String hash = PasswordUtils.hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, name);
        values.put(COL_USER_EMAIL, email.toLowerCase().trim());
        values.put(COL_USER_PASSWORD_HASH, hash);
        values.put(COL_USER_SALT, salt);

        try {
            return db.insertOrThrow(TABLE_USERS, null, values);
        } catch (Exception e) {
            // Most likely a UNIQUE constraint violation on email.
            return -1;
        }
    }

    /** Minimal result of a successful login lookup — never carries the password or hash. */
    public static class AuthResult {
        public final long userId;
        public final String name;
        public final String email;

        AuthResult(long userId, String name, String email) {
            this.userId = userId;
            this.name = name;
            this.email = email;
        }
    }

    /** Returns an {@link AuthResult} on success, or null if the credentials don't match. */
    public AuthResult authenticate(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID, COL_USER_NAME, COL_USER_EMAIL, COL_USER_PASSWORD_HASH, COL_USER_SALT},
                COL_USER_EMAIL + " = ?",
                new String[]{email.toLowerCase().trim()},
                null, null, null);

        AuthResult result = null;
        try {
            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD_HASH));
                String salt = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_SALT));

                if (PasswordUtils.verifyPassword(password, salt, storedHash)) {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME));
                    String userEmail = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL));
                    result = new AuthResult(id, name, userEmail);
                }
            }
        } finally {
            cursor.close();
        }
        return result;
    }

    // ============ Task operations ============

    /** Inserts a new task owned by {@code userId} and returns its new row id. */
    public long addTask(long userId, String title, String notes) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_USER_ID, userId);
        values.put(COL_TASK_TITLE, title);
        values.put(COL_TASK_NOTES, notes);
        values.put(COL_TASK_COMPLETE, 0);
        values.put(COL_TASK_CREATED_AT, System.currentTimeMillis());
        return db.insert(TABLE_TASKS, null, values);
    }

    /**
     * Returns every task belonging to {@code userId}, incomplete tasks first
     * (newest first within each group), so completed tasks settle to the bottom.
     */
    public List<Task> getTasksForUser(long userId) {
        List<Task> tasks = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_TASKS,
                null,
                COL_TASK_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                COL_TASK_COMPLETE + " ASC, " + COL_TASK_CREATED_AT + " DESC");

        try {
            while (cursor.moveToNext()) {
                Task task = new Task();
                task.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COL_TASK_ID)));
                task.setUserId(cursor.getLong(cursor.getColumnIndexOrThrow(COL_TASK_USER_ID)));
                task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COL_TASK_TITLE)));
                task.setNotes(cursor.getString(cursor.getColumnIndexOrThrow(COL_TASK_NOTES)));
                task.setComplete(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TASK_COMPLETE)) == 1);
                task.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_TASK_CREATED_AT)));
                tasks.add(task);
            }
        } finally {
            cursor.close();
        }
        return tasks;
    }

    public void setTaskComplete(long taskId, boolean complete) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_COMPLETE, complete ? 1 : 0);
        db.update(TABLE_TASKS, values, COL_TASK_ID + " = ?", new String[]{String.valueOf(taskId)});
    }

    public void deleteTask(long taskId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_TASKS, COL_TASK_ID + " = ?", new String[]{String.valueOf(taskId)});
    }
}
