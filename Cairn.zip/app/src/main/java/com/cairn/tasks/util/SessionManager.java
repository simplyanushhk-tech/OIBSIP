package com.cairn.tasks.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Tracks who is currently logged in. Deliberately stores nothing more than
 * the user's id, name, and email — never the password or its hash.
 */
public class SessionManager {

    private static final String PREF_NAME = "cairn_session";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final long NO_USER = -1L;

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void createSession(long userId, String name, String email) {
        prefs.edit()
                .putLong(KEY_USER_ID, userId)
                .putString(KEY_USER_NAME, name)
                .putString(KEY_USER_EMAIL, email)
                .apply();
    }

    public boolean isLoggedIn() {
        return prefs.getLong(KEY_USER_ID, NO_USER) != NO_USER;
    }

    public long getUserId() {
        return prefs.getLong(KEY_USER_ID, NO_USER);
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return prefs.getString(KEY_USER_EMAIL, "");
    }

    /** Clears the session so the app returns to a logged-out state. */
    public void logout() {
        prefs.edit().clear().apply();
    }
}
