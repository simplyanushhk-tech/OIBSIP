package com.cairn.tasks.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.cairn.tasks.R;

/**
 * Small dialog for entering a new task's name and optional notes.
 * The positive button's click listener is wired up manually (via
 * setOnShowListener) so it can validate and stay open on error, instead
 * of auto-dismissing like a default AlertDialog button would.
 */
public class AddTaskDialogFragment extends DialogFragment {

    public interface Listener {
        void onTaskCreate(String title, String notes);
    }

    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_add_task, null);

        EditText titleInput = view.findViewById(R.id.input_task_title);
        EditText notesInput = view.findViewById(R.id.input_task_notes);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(R.string.add_task_dialog_title)
                .setView(view)
                .setPositiveButton(R.string.action_save, null)
                .setNegativeButton(R.string.action_cancel, (d, which) -> dismiss())
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String notes = notesInput.getText().toString().trim();

            if (title.isEmpty()) {
                titleInput.setError(getString(R.string.error_task_title_required));
                return;
            }

            if (listener != null) {
                listener.onTaskCreate(title, notes);
            }
            dismiss();
        }));

        return dialog;
    }
}
