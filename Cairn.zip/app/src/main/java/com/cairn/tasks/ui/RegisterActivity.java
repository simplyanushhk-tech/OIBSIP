package com.cairn.tasks.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cairn.tasks.R;
import com.cairn.tasks.data.TaskDbHelper;
import com.cairn.tasks.util.SessionManager;

/**
 * Sign-up screen. On success, the new account is logged in immediately
 * (no separate trip back through the login form).
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText nameInput;
    private EditText emailInput;
    private EditText passwordInput;
    private TaskDbHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = TaskDbHelper.getInstance(this);
        sessionManager = new SessionManager(this);

        nameInput = findViewById(R.id.input_register_name);
        emailInput = findViewById(R.id.input_register_email);
        passwordInput = findViewById(R.id.input_register_password);
        Button registerButton = findViewById(R.id.button_register);
        TextView loginLink = findViewById(R.id.text_go_to_login);

        registerButton.setOnClickListener(v -> attemptRegister());
        loginLink.setOnClickListener(v -> finish());
    }

    private void attemptRegister() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (TextUtils.isEmpty(name)) {
            nameInput.setError(getString(R.string.error_name_required));
            return;
        }
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError(getString(R.string.error_invalid_email));
            return;
        }
        if (TextUtils.isEmpty(password) || password.length() < 6) {
            passwordInput.setError(getString(R.string.error_password_too_short));
            return;
        }

        long userId = dbHelper.registerUser(name, email, password);
        if (userId == -1) {
            Toast.makeText(this, R.string.error_email_taken, Toast.LENGTH_SHORT).show();
            return;
        }

        sessionManager.createSession(userId, name, email);

        Intent intent = new Intent(this, TaskListActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
