package com.cairn.tasks.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Basic password hashing helper.
 *
 * <p>SHA-256 combined with a random per-user salt is a reasonable baseline
 * for a learning/demo project and satisfies "do not store plain text
 * passwords." For a production app, prefer a dedicated password-hashing
 * algorithm such as bcrypt, scrypt, or Argon2 (via a library), which are
 * deliberately slow and far more resistant to brute-force/GPU cracking
 * than a single round of a general-purpose hash like SHA-256.
 */
public final class PasswordUtils {

    private static final int SALT_LENGTH_BYTES = 16;

    private PasswordUtils() {
        // no instances
    }

    /** Generates a new random salt, encoded as a hex string. */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        random.nextBytes(salt);
        return bytesToHex(salt);
    }

    /** Hashes {@code password} with {@code saltHex}, returning a hex-encoded digest. */
    public static String hashPassword(String password, String saltHex) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(hexToBytes(saltHex));
            byte[] hashed = digest.digest(password.getBytes("UTF-8"));
            return bytesToHex(hashed);
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            // SHA-256 and UTF-8 are guaranteed to be available on every
            // Android device, so this should never actually happen.
            throw new RuntimeException("Unable to hash password", e);
        }
    }

    /** Returns true if {@code password}, hashed with {@code saltHex}, matches {@code expectedHashHex}. */
    public static boolean verifyPassword(String password, String saltHex, String expectedHashHex) {
        String actualHash = hashPassword(password, saltHex);
        return actualHash.equalsIgnoreCase(expectedHashHex);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
