package com.cairn.tasks.ui;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cairn.tasks.R;
import com.cairn.tasks.model.Task;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView adapter backing the task list. Completed tasks get a
 * strikethrough on their title and are dimmed; ordering (completed tasks
 * last) is handled by the query in TaskDbHelper, not by this adapter.
 */
public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    public interface Listener {
        void onToggleComplete(Task task, boolean complete);
        void onDelete(Task task);
    }

    private final List<Task> tasks = new ArrayList<>();
    private final Listener listener;

    public TaskAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<Task> newTasks) {
        tasks.clear();
        tasks.addAll(newTasks);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        holder.bind(tasks.get(position), listener);
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        private final CheckBox checkBox;
        private final TextView titleView;
        private final TextView notesView;
        private final ImageButton deleteButton;

        TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.checkbox_task_complete);
            titleView = itemView.findViewById(R.id.text_task_title);
            notesView = itemView.findViewById(R.id.text_task_notes);
            deleteButton = itemView.findViewById(R.id.button_delete_task);
        }

        void bind(Task task, Listener listener) {
            titleView.setText(task.getTitle());

            if (task.getNotes() != null && !task.getNotes().trim().isEmpty()) {
                notesView.setText(task.getNotes());
                notesView.setVisibility(View.VISIBLE);
            } else {
                notesView.setVisibility(View.GONE);
            }

            // Clear the listener before setChecked so restoring saved state
            // doesn't fire a spurious onToggleComplete callback.
            checkBox.setOnCheckedChangeListener(null);
            checkBox.setChecked(task.isComplete());
            applyCompleteStyle(task.isComplete());

            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                applyCompleteStyle(isChecked);
                if (listener != null) {
                    listener.onToggleComplete(task, isChecked);
                }
            });

            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDelete(task);
                }
            });
        }

        private void applyCompleteStyle(boolean complete) {
            if (complete) {
                titleView.setPaintFlags(titleView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                titleView.setAlpha(0.55f);
            } else {
                titleView.setPaintFlags(titleView.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                titleView.setAlpha(1f);
            }
        }
    }
}
